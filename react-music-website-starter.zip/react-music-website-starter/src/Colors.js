export const orange = '#ebc214';
export const pink = '#d61eed';
export const white = '#f7f8fa';
