import React from 'react';
import Form from '../../components/Form/Form';
const Signup = () => {
	return <Form />;
};

export default Signup;
